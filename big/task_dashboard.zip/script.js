// We'll rewrite the JS to use correct column indexes (B-F)
let globalData = [];
let typoThreshold = 0.25;

window.onload = () => {
  fetch('status.xlsx')
    .then(res => res.arrayBuffer())
    .then(buffer => {
      const workbook = XLSX.read(buffer, { type: 'array' });
      const sheet = workbook.Sheets['Sheet1'];
      const rows = XLSX.utils.sheet_to_json(sheet, { header: 1 }).slice(2);

      globalData = rows.map(row => ({
        task: row[1],     // Column B
        info: row[2],     // Column C
        status: row[3],   // Column D
        id: row[4],       // Column E
        block: row[5] || ""  // Column F
      })).filter(r => r.task && r.status);

      renderTiles(globalData.filter(d => !d.status.toLowerCase().includes('completed')));
      document.getElementById('totalTasks').innerText = `Total tasks: ${globalData.length}`;
    });

  document.getElementById("togglePane").onclick = () => {
    document.getElementById("detailPane").classList.toggle("active")
  };

  const box = document.getElementById("searchBox");
  const dropdown = document.getElementById("customDropdown");
  box.onfocus = () => dropdown.style.display = "block";
  document.addEventListener("click", e => {
    if (!e.target.closest(".dropdown-wrapper")) dropdown.style.display = "none";
  });
  dropdown.querySelectorAll("div").forEach(opt => {
    opt.onclick = () => {
      box.value = opt.dataset.filter;
      searchTasks();
      dropdown.style.display = "none";
    };
  });
  box.addEventListener("keydown", e => { if (e.key === "Enter") searchTasks(); });

  if (window.matchMedia("(prefers-color-scheme: dark)").matches) {
    document.body.classList.add("dark");
  }
};

function renderTiles(data) {
  const container = document.getElementById("tileContainer");
  container.innerHTML = "";
  data.forEach(d => {
    const div = document.createElement("div");
    div.className = "task-tile";
    div.id = `tile@${d.id}`;
    div.innerHTML = `<div>${d.task}</div><div>${d.info}</div><div>${d.status}</div>`;
    div.onclick = () => {
      document.getElementById("paneContent").innerText = d.block || "No details available.";
      history.pushState(null, "", `?id=${d.id}`);
    };
    container.appendChild(div);
  });
}

function levenshtein(a, b) {
  const m = a.length, n = b.length;
  if (!m) return n; if (!n) return m;
  const dp = Array(m + 1).fill().map(() => Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
    }
  }
  return dp[m][n];
}

function searchTasks() {
  const input = document.getElementById("searchBox").value.trim().toLowerCase();
  const matched = [], backup = [];
  let corrected = input;

  globalData.forEach(d => {
    const full = `${d.task} ${d.info} ${d.status}`.toLowerCase();
    const block = d.block.toLowerCase();
    if (input === "all") return matched.push(d);
    if (input && d.status.toLowerCase().includes(input)) return matched.push(d);
    if (full.includes(input)) return matched.push(d);
    if (block.includes(input)) return backup.push(d);
    if (levenshtein(input, full) <= Math.floor(full.length * typoThreshold)) {
      corrected = d.task;
      return matched.push(d);
    }
    if (levenshtein(input, block) <= Math.floor(block.length * typoThreshold)) return backup.push(d);
  });

  renderTiles([...matched, ...backup]);
  document.getElementById("searchNote").innerText =
    (corrected !== input) ? `Searched for "${corrected}" instead of "${input}".` : "";
}
